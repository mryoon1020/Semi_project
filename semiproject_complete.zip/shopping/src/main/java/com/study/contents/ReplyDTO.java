package com.study.contents;
public class ReplyDTO {
  private int rnum;
  private String contents;
  private String regdate;
  private String id;
  private int contentsno;
  public int getRnum() {
    return rnum;
  }
  public void setRnum(int rnum) {
    this.rnum = rnum;
  }
  public String getContent() {
    return contents;
  }
  public void setContent(String contents) {
    this.contents = contents;
  }
  public String getRegdate() {
    return regdate;
  }
  public void setRegdate(String regdate) {
    this.regdate = regdate;
  }
  public String getId() {
    return id;
  }
  public void setId(String id) {
    this.id = id;
  }
  public int getContentsno() {
    return contentsno;
  }
  public void setContentsno(int contentsno) {
    this.contentsno = contentsno;
  }
  
  
}